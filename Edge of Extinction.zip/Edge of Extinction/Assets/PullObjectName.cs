﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PullObjectName : MonoBehaviour {
    public GameObject currentObject;
	// Use this for initialization
	void Start () {
        currentObject = GetComponent()
        Debug.Log(currentObject.name);
	}

}
