﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectData : MonoBehaviour {
    public GameObject currentObject;
    public int testVal;
	// Use this for initialization
	void Start () {
       testVal = Random.Range(1, 254);
    }

}
