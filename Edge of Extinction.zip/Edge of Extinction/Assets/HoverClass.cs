﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HoverClass : MonoBehaviour {
    public Renderer rend;
    public Component halo;
    void Start()
    {
        //Sets the collider check to activate on triggers -- This is an option in the Collider settings in Unity
        Physics.queriesHitTriggers = true;
        rend = GetComponent<Renderer>();
    }
    void OnMouseEnter()
    {
        rend.material.color = Color.yellow;
        transform.localScale += new Vector3(0.4F, 0.4F, 0.4F);
    }
    void OnMouseExit()
    {
        rend.material.color = Color.white;
        transform.localScale -= new Vector3(0.4F, 0.4F, 0.4F);
    }
}
