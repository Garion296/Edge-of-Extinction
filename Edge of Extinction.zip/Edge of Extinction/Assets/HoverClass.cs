﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class HoverClass : MonoBehaviour {
    //declarations of object names
    public Renderer rend;
    public Component halo;
    public ObjectData valGrab;
    //method that runs on start, used to generate initial settings and objects
    void Start()
    {
        //Sets the collider check to activate on triggers -- This is an option in the Collider settings in Unity
        Physics.queriesHitTriggers = true;
        //creates a rend object, so that the renderer can check for collisions
        rend = GetComponent<Renderer>();
        //creates a valGrab object, to read in info from the object's data class
        valGrab = GetComponent<ObjectData>();
    }
    //method that runs when you mouse over an object
    void OnMouseEnter()
    {
        //sets object's color
        rend.material.color = Color.yellow;
        //increases the object's size
        transform.localScale += new Vector3(0.4F, 0.4F, 0);
        //decrease's the object's depth, making it appear above other objects
        transform.localPosition -= new Vector3(0, 0, 1);
        //prints out the info from the object's data class
       // Debug.Log(valGrab.testVal);
    }
    //method that runs when you stop mousing over an object, to reset it
    void OnMouseExit()
    {
        //resets the object's color
        rend.material.color = Color.white;
        //resets the object's size
        transform.localScale -= new Vector3(0.4F, 0.4F, 0);
        //resets the object's depth
        transform.localPosition += new Vector3(0, 0, 1);
    }
}
